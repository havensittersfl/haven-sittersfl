# Haven Sitters website

A one-page site: plain HTML, CSS and a little JavaScript. No build step.

## Files
- `index.html` has all the page content
- `css/styles.css` has the brand colors, fonts and layout (colors are at the top)
- `js/sitters.js` holds the sitter showcase; add sitters here
- `images/` holds the logo and photos

## Before you publish (search the files for TODO)
1. Replace `YOUR-LINK` with your Calendly link. It appears 3 times in `index.html`.
2. Swap `images/bianca.jpg` for your photo, square if possible.
3. When the sitter Google Form is ready, replace the `mailto:` link in the "Join" section.
4. Check the Instagram, TikTok and Facebook links in the footer.

## Put it on GitHub Pages
1. Create a new public repo on GitHub, e.g. `haven-sitters`.
2. Upload these files (or `git push`) so `index.html` is at the top level of the repo.
3. Go to the repo's **Settings > Pages**, set Source to **Deploy from a branch**, then pick `main` and `/ (root)` and save.
4. After a minute or two, the site is live at `https://YOUR-USERNAME.github.io/haven-sitters/`.

## Connect your domain
1. Buy the domain (Cloudflare Registrar, Porkbun or Namecheap).
2. At your domain company, add these DNS records:
   - Four **A** records for `@` pointing to 185.199.108.153, 185.199.109.153, 185.199.110.153 and 185.199.111.153
   - A **CNAME** record for `www` pointing to `YOUR-USERNAME.github.io` (without the repo name)
3. On GitHub, go to **Settings > Pages > Custom domain**, enter your domain and click Save.
4. Once the option appears, tick **Enforce HTTPS**. It can take up to 24 hours.

## Adding a sitter
Open `js/sitters.js`, copy the example block, fill it in, and add their photo to `images/`.
Only add sitters who have agreed to be on the site.
